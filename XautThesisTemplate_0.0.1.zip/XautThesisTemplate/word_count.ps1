[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
texcount -inc -sum .\main.tex